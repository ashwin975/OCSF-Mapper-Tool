"""ocsf_mapper — generate Lakewatch presets from vendor samples.

Public API:
    from ocsf_mapper import run
    run(sample_path=..., vendor=..., source_type=...)

For more control, individual stages are importable:
    from ocsf_mapper import classify_sample, generate_preset, fetch_all
"""
from .pipeline import run
from .classifier import classify_sample, render_suggestions
from .fetch_ocsf import fetch_all
from .generator import generate_preset
from .schema_loader import list_classes, lookup_class, summarize_cache
from .profiler import detect_format, profile
from .reference_library import scan_library, select_references, describe_selection

__version__ = "0.3.2"

__all__ = [
    "run",
    "classify_sample",
    "render_suggestions",
    "fetch_all",
    "generate_preset",
    "list_classes",
    "lookup_class",
    "summarize_cache",
    "detect_format",
    "profile",
    "__version__",
]
